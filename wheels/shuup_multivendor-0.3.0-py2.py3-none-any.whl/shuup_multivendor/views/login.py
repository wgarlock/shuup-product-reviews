# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.core.urlresolvers import reverse
from shuup.front.apps.auth.views import LoginView as BaseLoginView

from shuup_multivendor.models import SupplierUser


class LoginView(BaseLoginView):
    def get_success_url(self):
        # redirect to admin if the user is a vendor user
        if SupplierUser.objects.filter(user=self.request.user).exists():
            return reverse("shuup_admin:dashboard")

        return super(LoginView, self).get_success_url()

# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.conf import settings
from django.db import models
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum, EnumField
from shuup.core.fields import MoneyValueField
from shuup.core.models import Product, Shop, ShuupModel, Supplier
from shuup.utils.properties import MoneyPropped, PriceProperty


class DistanceUnit(Enum):
    km = "km"
    mi = "mi"

    class Labels:
        km = _("Kilometers")
        mi = _("Miles")


class DayOfTheWeek(Enum):
    Monday = "monday"
    Tuesday = "tuesday"
    Wednesday = "wednesday"
    Thursday = "thursday"
    Friday = "friday"
    Saturday = "saturday"
    Sunday = "sunday"

    class Labels:
        Monday = _("Monday")
        Tuesday = _("Tuesday")
        Wednesday = _("Wednesday")
        Thursday = _("Thursday")
        Friday = _("Friday")
        Saturday = _("Saturday")
        Sunday = _("Sunday")


class SupplierPrice(MoneyPropped, ShuupModel):
    shop = models.ForeignKey(Shop, related_name="vendor_prices")
    product = models.ForeignKey(Product, related_name="vendor_prices")
    supplier = models.ForeignKey(Supplier, related_name="vendor_prices")
    amount_value = MoneyValueField()
    amount = PriceProperty("amount_value", "shop.currency", "shop.prices_include_tax")


class SupplierUser(models.Model):
    shop = models.ForeignKey(Shop, related_name="vendor_users")
    supplier = models.ForeignKey(Supplier, related_name="vendor_users")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="vendor_users")

    class Meta:
        unique_together = ("shop", "supplier", "user")


class VendorContactDistance(models.Model):
    contact = models.ForeignKey("shuup.Contact", verbose_name=_("contact"), related_name="vendor_distances")
    supplier = models.ForeignKey("shuup.Supplier", verbose_name=_("supplier"), related_name="vendor_distances")
    distance = models.DecimalField(verbose_name=_("distance"), null=True, blank=True, max_digits=9, decimal_places=2)
    unit = EnumField(DistanceUnit, verbose_name=_("unit"))

    class Meta:
        unique_together = ("contact", "supplier")

    def __str__(self):
        return "{} => {} = {} {}".format(self.contact, self.supplier, self.distance, self.unit)

# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from shuup.core.models import OrderLine, Shipment, ShippingMode

from shuup_multivendor.utils.configuration import (
    get_completed_status_label_for_shop
)


def is_order_initial(order, supplier=None):
    """
    The order is in initial state when there is no shipment and no labels set
    """
    shipments = Shipment.objects.filter(order=order)
    lines = OrderLine.objects.products().filter(order=order, labels__isnull=False)

    if supplier:
        shipments = shipments.filter(supplier=supplier)
        lines = lines.filter(supplier=supplier)

    return (not shipments.exists() and not lines.exists())


def _filter_queryset(queryset, supplier, line):
    if supplier:
        queryset = queryset.filter(supplier=supplier)

    if line:
        queryset = queryset.filter(id=line.id)
    return queryset


def is_order_completed(order, supplier=None, line=None):
    """
    The order will be completed when all order lines have the completed label and all lines are shipped.

    If the order doesn't contain lines to be shipped, the result will be calculated using only the order line status.
    If the completion status is not configured, the result is calculated using only the shipped status.

    If `supplier` is None, all order lines will be considered.
    """
    shippable_lines = order.lines.products().filter(product__shipping_mode=ShippingMode.SHIPPED)
    shippable_lines = _filter_queryset(shippable_lines, supplier, line)

    lines_to_ship = shippable_lines.count()
    shipped = True  # default

    if lines_to_ship:
        shipped_lines = 0

        for line in shippable_lines:
            shipments = Shipment.objects.filter(order=order, products__product_id=line.product_id)
            shipments = _filter_queryset(shipments, supplier, line)

            shipped_lines += shipments.count()

        shipped = (shipped_lines == lines_to_ship)

    completed_status_label = get_completed_status_label_for_shop(order.shop)
    if not completed_status_label:
        return shipped

    lines = OrderLine.objects.products().filter(order=order)
    lines = _filter_queryset(lines, supplier, line)

    # there are lines that doesn't have the completed label, order is not completed
    return (not lines.exclude(labels=completed_status_label).exists() and shipped)


def is_line_complete(order_line):
    return is_order_completed(order_line.order, order_line.supplier, order_line)

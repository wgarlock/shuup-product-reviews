# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.core.urlresolvers import reverse
from django.dispatch import receiver
from django.utils.translation import get_language
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import Supplier
from shuup.core.order_creator.signals import order_creator_finished
from shuup.notify.base import Event, Variable
from shuup.notify.typology import Email, Language, Model, Phone, Text, URL

from shuup_multivendor.signals import (
    all_order_lines_completed, order_line_status_changed, vendor_approved,
    vendor_order_completed, vendor_registered
)


class VendorOrderReceived(Event):
    identifier = "vendor_order_received"
    name = _("Vendor Order Received")
    description = _("This event is triggered for each vendor when an order is received.")

    order = Variable(
        _("Order"),
        type=Model("shuup.Order"),
        help_text=_("To access vendor lines, use: {{ order.vendor_lines }}")
    )
    customer_email = Variable(_("Customer Email"), type=Email)
    customer_phone = Variable(_("Customer Phone"), type=Phone)

    vendor_name = Variable(_("Vendor name"), type=Text)
    vendor_email = Variable(_("Vendor email"), required=False, type=Email)
    vendor_phone = Variable(_("Vendor phone"), required=False, type=Phone)
    vendor_address = Variable(_("Vendor address"), required=False, type=Text)

    shop_email = Variable(_("Shop Email"), type=Email)
    shop_phone = Variable(_("Shop Phone"), type=Phone)

    language = Variable(_("Language"), type=Language)


class VendorRegistered(Event):
    identifier = "vendor_registered"
    name = _("Vendor Registered")
    description = _("This event is triggered when a new vendor registers.")

    vendor_name = Variable(_("Vendor name"), type=Text)
    vendor_email = Variable(_("Vendor email"), required=False, type=Email)
    vendor_phone = Variable(_("Vendor phone"), required=False, type=Phone)
    vendor_address = Variable(_("Vendor address"), required=False, type=Text)

    shop_name = Variable(_("Shop name"), type=Text)
    shop_email = Variable(_("Shop email"), required=False, type=Email)
    shop_phone = Variable(_("Shop phone"), required=False, type=Phone)

    language = Variable(_("Language"), type=Language)


class VendorApproved(Event):
    identifier = "vendor_approved"
    name = _("Vendor Approved")
    description = _("This event is triggered when a vendor is approved.")

    vendor_name = Variable(_("Vendor name"), type=Text)
    vendor_email = Variable(_("Vendor email"), required=False, type=Email)
    vendor_phone = Variable(_("Vendor phone"), required=False, type=Phone)
    vendor_address = Variable(_("Vendor address"), required=False, type=Text)

    shop_name = Variable(_("Shop name"), type=Text)
    shop_email = Variable(_("Shop email"), required=False, type=Email)
    shop_phone = Variable(_("Shop phone"), required=False, type=Phone)

    management_url = Variable(_("Vendor management URL"), type=URL)
    language = Variable(_("Language"), type=Language)


class OrderLineStatusChanged(Event):
    identifier = "order_line_status_changed"
    name = _("Order Line Status Changed")
    description = _("This event is triggered for order line when the status changes.")

    order = Variable(_("Order"), type=Model("shuup.Order"))
    order_line = Variable(_("Order line"), type=Model("shuup.OrderLine"))

    shop_name = Variable(_("Shop name"), type=Text)
    shop_email = Variable(_("Shop email"), required=False, type=Email)
    shop_phone = Variable(_("Shop phone"), required=False, type=Phone)

    vendor_name = Variable(_("Vendor name"), type=Text)
    vendor_email = Variable(_("Vendor email"), required=False, type=Email)
    vendor_phone = Variable(_("Vendor phone"), required=False, type=Phone)
    vendor_address = Variable(_("Vendor address"), required=False, type=Text)

    previous_status_name = Variable(_("Previous status name"), type=Text)
    new_status_name = Variable(_("New status name"), type=Text)

    language = Variable(_("Language"), type=Language)


class AllOrderLinesCompleted(Event):
    identifier = "all_order_lines_completed"
    name = _("All Order Lines Completed")
    description = _("This event is triggered when all order lines have the completed status set.")

    order = Variable(_("Order"), type=Model("shuup.Order"))

    customer_email = Variable(_("Customer Email"), required=False, type=Email)
    customer_phone = Variable(_("Customer Phone"), required=False, type=Phone)

    shop_name = Variable(_("Shop name"), type=Text)
    shop_email = Variable(_("Shop email"), required=False, type=Email)
    shop_phone = Variable(_("Shop phone"), required=False, type=Phone)

    language = Variable(_("Language"), type=Language)


class VendorOrderCompleted(Event):
    identifier = "vendor_order_completed"
    name = _("Vendor Order Completed")
    description = _("This event is triggered when all order lines of a single vendor are in a completed status.")

    order = Variable(
        _("Order"),
        type=Model("shuup.Order"),
        help_text=_("To access vendor lines, use: {{ order.vendor_lines }}")
    )

    vendor_name = Variable(_("Vendor name"), type=Text)
    vendor_email = Variable(_("Vendor email"), required=False, type=Email)
    vendor_phone = Variable(_("Vendor phone"), required=False, type=Phone)
    vendor_address = Variable(_("Vendor address"), required=False, type=Text)

    customer_email = Variable(_("Customer Email"), required=False, type=Email)
    customer_phone = Variable(_("Customer Phone"), required=False, type=Phone)

    shop_name = Variable(_("Shop name"), type=Text)
    shop_email = Variable(_("Shop email"), required=False, type=Email)
    shop_phone = Variable(_("Shop phone"), required=False, type=Phone)

    language = Variable(_("Language"), type=Language)


def _get_vendor_address(vendor):
    if not vendor.contact_address:
        return ""

    address = vendor.contact_address
    lines = [
        address.street,
        address.street2,
        address.street3,
        address.city,
        address.region,
        address.region_code,
        address.postal_code
    ]
    lines = [line for line in lines if line]
    return ", ".join(lines)


@receiver(vendor_registered)
def send_vendor_registered_notification(shop, vendor, user, person_contact, **kwargs):
    params = dict(
        shop_name=(shop.public_name or shop.name),
        shop_email=(shop.contact_address.email if shop.contact_address else ""),
        shop_phone=(shop.contact_address.phone if shop.contact_address else ""),

        vendor_name=vendor.name,
        vendor_email=vendor.contact_address.email if vendor.contact_address else "",
        vendor_phone=vendor.contact_address.phone if vendor.contact_address else "",
        vendor_address=_get_vendor_address(vendor),
        language=get_language()
    )
    VendorRegistered(**params).run(shop=shop)


@receiver(vendor_approved)
def send_vendor_approved_notification(shop, vendor, request, **kwargs):
    shop = vendor.shops.first()
    management_url = request.build_absolute_uri(reverse("shuup_admin:dashboard"))
    params = dict(
        shop_name=(shop.public_name or shop.name),
        shop_email=(shop.contact_address.email if shop.contact_address else ""),
        shop_phone=(shop.contact_address.phone if shop.contact_address else ""),

        vendor_name=vendor.name,
        vendor_email=vendor.contact_address.email if vendor.contact_address else "",
        vendor_phone=vendor.contact_address.phone if vendor.contact_address else "",
        vendor_address=_get_vendor_address(vendor),
        management_url=management_url,
        language=get_language()
    )
    VendorApproved(**params).run(shop=shop)


@receiver(order_line_status_changed)
def send_order_line_status_changed_notification(order, order_line, vendor, vendor_user,
                                                previous_status, new_status, **kwargs):
    shop = order.shop
    params = dict(
        order=order,
        order_line=order_line,
        shop_name=(shop.public_name or shop.name),
        shop_email=(shop.contact_address.email if shop.contact_address else ""),
        shop_phone=(shop.contact_address.phone if shop.contact_address else ""),
        vendor_name=vendor.name,
        vendor_email=vendor.contact_address.email if vendor.contact_address else "",
        vendor_phone=vendor.contact_address.phone if vendor.contact_address else "",
        vendor_address=_get_vendor_address(vendor),
        previous_status_name=(previous_status.name if previous_status else ""),
        new_status_name=(new_status.name if new_status else ""),
        language=order.language
    )
    OrderLineStatusChanged(**params).run(shop=shop)


@receiver(all_order_lines_completed)
def send_all_order_lines_completed_notification(order, **kwargs):
    shop = order.shop
    params = dict(
        order=order,
        customer_email=order.email,
        customer_phone=order.phone,
        shop_name=(shop.public_name or shop.name),
        shop_email=(shop.contact_address.email if shop.contact_address else ""),
        shop_phone=(shop.contact_address.phone if shop.contact_address else ""),
        language=order.language
    )
    AllOrderLinesCompleted(**params).run(shop=shop)


@receiver(vendor_order_completed)
def send_vendor_order_completed_notification(vendor, order, lines, **kwargs):
    shop = order.shop
    order.vendor_lines = lines
    params = dict(
        order=order,

        vendor_name=vendor.name,
        vendor_email=vendor.contact_address.email if vendor.contact_address else "",
        vendor_phone=vendor.contact_address.phone if vendor.contact_address else "",
        vendor_address=_get_vendor_address(vendor),

        customer_email=order.email,
        customer_phone=order.phone,

        shop_name=(shop.public_name or shop.name),
        shop_email=(shop.contact_address.email if shop.contact_address else ""),
        shop_phone=(shop.contact_address.phone if shop.contact_address else ""),

        language=order.language
    )
    VendorOrderCompleted(**params).run(shop=shop)


@receiver(order_creator_finished)
def send_order_received_notification(order, **kwargs):
    params = dict(
        customer_email=order.email,
        customer_phone=order.phone,
        shop_email=None,
        shop_phone=None,
        language=order.language
    )

    if order.shop.contact_address:
        params.update(dict(
            shop_email=order.shop.contact_address.email,
            shop_phone=order.shop.contact_address.phone
        ))

    for vendor in Supplier.objects.filter(pk__in=order.lines.products().values("supplier")).distinct():
        order.vendor_lines = order.lines.products().filter(supplier=vendor)

        params.update(dict(
            order=order,
            vendor_name=vendor.name,
            vendor_email=vendor.contact_address.email if vendor.contact_address else "",
            vendor_phone=vendor.contact_address.phone if vendor.contact_address else "",
            vendor_address=_get_vendor_address(vendor)
        ))

        VendorOrderReceived(**params).run(shop=order.shop)

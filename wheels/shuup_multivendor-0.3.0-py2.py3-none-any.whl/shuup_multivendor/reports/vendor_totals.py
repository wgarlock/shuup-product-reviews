# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import decimal
import itertools

from django import forms
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.models import OrderLine, OrderStatusRole
from shuup.core.pricing import TaxfulPrice, TaxlessPrice
from shuup.reports.forms import BaseReportForm
from shuup.reports.report import ShuupReportBase


class SummaryForm(BaseReportForm):
    vendor_share = forms.DecimalField(
        required=False,
        label=_("Vendor share percentage"),
        help_text=_("Vendor share percentage. Use vakues between 0-100 for best result.")
    )


class VendorSummaryReport(ShuupReportBase):
    identifier = "multivendor_vendors_summary_report"
    title = _("Marketplace Vendors Summary Report")
    filename_template = "sales-report-%(time)s"
    form_class = SummaryForm
    schema = []

    def __init__(self, **kwargs):
        super(VendorSummaryReport, self).__init__(**kwargs)
        self.schema = [
            {"key": "text", "title": _("Vendor")},
            {"key": "order_count", "title": _("Order Count")},
            {"key": "order_line_count", "title": _("Order Line Count")},
            {"key": "taxless_total", "title": _("Taxless Total")},
        ]
        if self.options.get("vendor_share"):
            self.schema += [
                {"key": "taxless_vendor_share", "title": _("Vendor Share Taxless")},
                {"key": "taxless_marketplace_share", "title": _("Marketplace Share Taxless")},
            ]

        self.schema += [
            {"key": "taxful_total", "title": _("Taxful Total")},
        ]
        if self.options.get("vendor_share"):
            self.schema += [
                {"key": "taxful_vendor_share", "title": _("Vendor Share Taxful")},
                {"key": "taxful_marketplace_share", "title": _("Marketplace Share Taxful")},
            ]

    def get_objects(self):
        shop = get_shop(self.request)
        # TODO: Maybe make raw sql or values_list query in future
        queryset = OrderLine.objects.filter(
            order__shop=shop,
            order__status__role=OrderStatusRole.COMPLETE
        ).order_by("supplier__name")

        if self.start_date:
            queryset = queryset.filter(order__order_date__gte=self.start_date)

        if self.end_date:
            queryset = queryset.filter(order__order_date__lte=self.end_date)

        return queryset

    def get_data(self):
        data = []

        def _extract_supplier_name(entity):
            return (entity.supplier.name if entity.supplier else None)

        vendor_share = ((self.options.get("vendor_share") or decimal.Decimal("0")) / 100)
        for supplier_name, order_lines in itertools.groupby(self.get_objects(), key=_extract_supplier_name):
            if not supplier_name:
                continue

            taxless_total = TaxlessPrice(0, currency=self.shop.currency)
            taxful_total = TaxfulPrice(0, currency=self.shop.currency)
            order_ids = set()
            order_line_count = 0
            for line in order_lines:
                taxless_total += line.taxless_price
                taxful_total += line.taxful_price
                order_line_count += 1
                order_ids.add(line.order_id)

            vendor_share_taxless = vendor_share * taxless_total
            vendor_share_taxful = vendor_share * taxful_total
            data.append({
                # "date": format_date(order_date, locale=get_current_babel_locale()),
                "text": supplier_name,
                "order_count": len(order_ids),
                "order_line_count": int(order_line_count),
                "taxless_total": taxless_total.as_rounded().value,
                "taxless_vendor_share": vendor_share_taxless.as_rounded().value,
                "taxless_marketplace_share": (taxless_total - vendor_share_taxless).as_rounded().value,
                "taxful_total": taxful_total.as_rounded().value,
                "taxful_vendor_share": vendor_share_taxful.as_rounded().value,
                "taxful_marketplace_share": (taxful_total - vendor_share_taxful).as_rounded().value,
            })

        return self.get_return_data(data)

function adjustPrice(event, productId, supplierId, button) {
    event.preventDefault();
    event.stopPropagation();

    const newPrice = $(button).first().parents("div").first().prev().val();
    if (!newPrice) {
        alert("Cannot set empty price or zero");
        return false;
    }

    $.ajax({
        url: "/admin/multivendor/products/set-price/", // TODO: URLIFY
        type: "POST",
        data: {
            productId,
            supplierId,
            csrfmiddlewaretoken: window.ShuupAdminConfig.csrf,
            price: newPrice
        },
        success: function() {
            const onSaleToggleButton = $(`#toggle-on-sale-${productId}`);
            if (onSaleToggleButton.length > 0) {
                onSaleToggleButton
                    .addClass("btn-danger")
                    .removeClass("btn-success")
                    .text(gettext("Stop selling this product"));
            }

            window.Messages.enqueue({
                tags: "success",
                text: gettext("New product price set successfully.")
            });
        },
        error: function () {
            window.Messages.enqueue({
                tags: "error",
                text: gettext("An error has occurred while setting product price, please try again.")
            });
        }
    });
}


function toggleOnSale(event, productId, supplierId) {
    event.preventDefault();
    event.stopPropagation();

    $.ajax({
        url: "/admin/multivendor/products/toggle-sale/", // TODO: URLIFY
        type: "POST",
        dataType: "json",
        data: {
            productId,
            supplierId,
            csrfmiddlewaretoken: window.ShuupAdminConfig.csrf
        },
        success: function(response) {
            const onSaleToggleButton = $(`#toggle-on-sale-${productId}`);
            if (onSaleToggleButton.length > 0) {
                if (response.isInSale) {
                    onSaleToggleButton
                        .addClass("btn-danger")
                        .removeClass("btn-success")
                        .text(gettext("Stop selling this product"));

                    window.Messages.enqueue({
                        tags: "success",
                        text: gettext("Product is now ready for sale!")
                    });
                } else {
                    onSaleToggleButton
                        .addClass("btn-success")
                        .removeClass("btn-danger")
                        .text(gettext("Start selling this product"));

                    window.Messages.enqueue({
                        tags: "success",
                        text: gettext("Product removed from sale!")
                    });
                }
            }
        },
        error: function () {
            window.Messages.enqueue({
                tags: "error",
                text: gettext("An error has occurred while publishing product, please try again.")
            });
        }
    });
}

window.adjustPrice = adjustPrice;
window.toggleOnSale = toggleOnSale;

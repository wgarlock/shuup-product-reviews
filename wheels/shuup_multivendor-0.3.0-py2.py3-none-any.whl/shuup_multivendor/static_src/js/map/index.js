import m from "mithril";
import prop from "mithril/stream";
import loadGoogleMapsAPI from "load-google-maps-api";

import "../../less/map.less";    // import styles
import MapView from "./view";

const rootElement = document.getElementById("vendor-map");

const VendorMap = {
    oninit(vnode) {
        vnode.state.vendors = prop([]);

        const vendorsUrl = rootElement.getAttribute("data-vendors-url");
        m.request({
            url: vendorsUrl,
            config: function(xhr) {
                xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")  // enables is_ajax in Django
              }
        }).then((response) => {
            vnode.state.vendors(response);
        }).catch((error) => console.error(error));
    },
    view(vnode) {
        if (!vnode.state.vendors().length) return null;

        return m(MapView, {
            vendors: vnode.state.vendors()
        });
    }
};

if (rootElement) {
    if(window.VENDOR_MAP_SETTINGS && window.VENDOR_MAP_SETTINGS.gmaps_api_key) {
        loadGoogleMapsAPI({
            key: window.VENDOR_MAP_SETTINGS.gmaps_api_key,
            libraries: ["places"]
        }).then(() => {
            m.mount(rootElement, VendorMap);
        }).catch((err) => {
            console.error(err);
        });
    } else {
        console.warn("Invalid settings. The map was not initialized.");
    }
}

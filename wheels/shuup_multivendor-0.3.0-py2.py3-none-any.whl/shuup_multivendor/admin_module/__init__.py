# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist
from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import (
    ORDERS_MENU_CATEGORY, PRODUCTS_MENU_CATEGORY, SETTINGS_MENU_CATEGORY
)
from shuup.admin.utils.urls import admin_url, get_edit_and_list_urls
from shuup.core.models import Product, ShopProduct


class MultivendorProductsAdminModule(AdminModule):
    name = _("Vendor Products")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:shuup_multivendor.products_list")

    def get_urls(self):
        urls = [
            admin_url(
                r"^multivendor/products/$",
                "shuup_multivendor.admin_module.views.ProductListView",
                name="shuup_multivendor.products_list",
            ),
            admin_url(
                r"^multivendor/products/toggle-sale/$",
                "shuup_multivendor.admin_module.views.ToggleSaleView",
                name="shuup_multivendor.products_toggles_sale",
            ),
            admin_url(
                r"^multivendor/products/set-price/$",
                "shuup_multivendor.admin_module.views.SetPriceView",
                name="shuup_multivendor.products_set_price",
            )
        ]
        if settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS:
            urls += [
                admin_url(
                    r"^multivendor/products/new/$",
                    "shuup_multivendor.admin_module.views.ProductEditView",
                    name="shuup_multivendor.products_new",
                    kwargs={"pk": None}
                ),
                admin_url(
                    r"^multivendor/products/(?P<pk>\d+)/$",
                    "shuup_multivendor.admin_module.views.ProductEditView",
                    name="shuup_multivendor.products_edit"
                ),
                admin_url(
                    r"^multivendor/products/(?P<pk>\d+)/delete/$",
                    "shuup_multivendor.admin_module.views.ProductDeleteView",
                    name="shuup_multivendor.products_delete"
                )
            ]
        return urls

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=_("Products"),
                icon="fa fa-image",
                url="shuup_admin:shuup_multivendor.products_list",
                category=PRODUCTS_MENU_CATEGORY,
                subcategory="products"
            )
        ]

    def get_model_url(self, object, kind, shop=None):
        if settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS and isinstance(object, (Product, ShopProduct)):
            if not object.pk:
                return reverse("shuup_admin:shuup_multivendor.products_new")

            if isinstance(object, Product):
                if not shop:
                    try:
                        shop = object.shop_products.first().shop
                    except ObjectDoesNotExist:
                        return None
                object = object.get_shop_instance(shop)

            return reverse("shuup_admin:shuup_multivendor.products_edit", kwargs={"pk": object.pk})


class MultivendorOrdersAdminModule(AdminModule):
    name = _("Vendor Orders")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:shuup_multivendor.order_list")

    def get_urls(self):
        return [
            admin_url(
                r"^multivendor/orders/(?P<pk>\d+)/create-shipment/$",
                "shuup_multivendor.admin_module.views.create_shipment",
                name="shuup_multivendor.create_shipment",
            ),
            admin_url(
                r"^multivendor/orders/(?P<pk>\d+)/set-line-status/$",
                "shuup_multivendor.admin_module.views.set_order_line_status",
                name="shuup_multivendor.set_line_status",
            ),
            admin_url(
                r"^multivendor/orders/(?P<pk>\d+)/lines$",
                "shuup_multivendor.admin_module.views.OrderLineListView",
                name="shuup_multivendor.order_line_list",
            ),
            admin_url(
                r"^multivendor/orders/$",
                "shuup_multivendor.admin_module.views.OrderListView",
                name="shuup_multivendor.order_list",
            )
        ]

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=self.name,
                icon="fa fa-inbox",
                url="shuup_admin:shuup_multivendor.order_list",
                category=ORDERS_MENU_CATEGORY,
                subcategory="orders"
            )
        ]


class MultivendorVendorAdminModule(AdminModule):
    name = _("Vendors Management")
    breadcrumbs_menu_entry = MenuEntry(text=name, url="shuup_admin:shuup_multivendor.vendor.list")

    def get_urls(self):
        return get_edit_and_list_urls(
            url_prefix="^vendor",
            view_template="shuup_multivendor.admin_module.views.Vendor%sView",
            name_template="shuup_multivendor.vendor.%s",
        ) + [
            admin_url(
                r"^vendor/(?P<pk>\d+)/login-as/$",
                "shuup_multivendor.admin_module.views.LoginAsVendorView",
                name="shuup_multivendor.vendor.login-as",
            )
        ]

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=self.name,
                icon="fa fa-list",
                url="shuup_admin:shuup_multivendor.vendor.list",
                category=SETTINGS_MENU_CATEGORY,
                subcategory="other_settings"
            )
        ]


class VendorSettingsAdminModule(AdminModule):
    name = _("Vendor Settings")
    breadcrumbs_menu_entry = MenuEntry(text=name, url="shuup_admin:shuup_multivendor.vendor.settings")

    def get_urls(self):
        return [
            admin_url(
                r"^multivendor/settings/$",
                "shuup_multivendor.admin_module.views.VendorSettingsView",
                name="shuup_multivendor.vendor.settings",
            )
        ]

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=self.name,
                icon="fa fa-list",
                url="shuup_admin:shuup_multivendor.vendor.settings",
                category=SETTINGS_MENU_CATEGORY,
                subcategory="other_settings"
            )
        ]

# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import unicode_literals

from django.conf import settings as django_settings
from django.contrib import messages
from django.contrib.auth import load_backend, login
from django.core.exceptions import PermissionDenied
from django.core.urlresolvers import reverse
from django.http.response import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic import View
from shuup.admin.shop_provider import get_shop
from shuup.admin.utils.permissions import has_permission
from shuup.utils.excs import Problem

from shuup_multivendor.models import SupplierUser


class LoginAsVendorView(View):
    def post(self, request, *args, **kwargs):
        if not has_permission(request.user, "shuup_multivendor.vendor.login-as"):
            raise PermissionDenied

        supplier_user = SupplierUser.objects.filter(
            shop=get_shop(request),
            supplier_id=kwargs["pk"],
            user__is_superuser=False,
            user__is_active=True
        ).first()

        if not supplier_user:
            raise Problem(_("Invalid supplier"))

        user = supplier_user.user

        if user == request.user:
            raise Problem(_("You are already logged in."))

        if not hasattr(user, "backend"):
            for backend in django_settings.AUTHENTICATION_BACKENDS:
                if user == load_backend(backend).get_user(user.pk):
                    user.backend = backend
                    break

        login(request, user)
        request.session["impersonator_user_id"] = user.pk
        message = _("You're now logged in as {username}").format(username=user.username)
        messages.success(request, message)
        return HttpResponseRedirect(reverse("shuup_admin:dashboard"))

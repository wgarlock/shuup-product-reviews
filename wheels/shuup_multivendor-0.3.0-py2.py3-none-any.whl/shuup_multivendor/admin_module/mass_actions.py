# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.utils.picotable import (
    PicotableJavascriptMassAction, PicotableMassActionProvider
)


class OrderLineCreateShipmentMassActionProvider(PicotableMassActionProvider):
    @classmethod
    def get_mass_actions_for_view(cls, view):
        order = getattr(view, "order", None)
        if order and order.can_create_shipment():
            return [
                "shuup_multivendor.admin_module.mass_actions:CreateShipmentMassAction"
            ]
        return []


class CreateShipmentMassAction(PicotableJavascriptMassAction):
    label = _("Create Shipments")
    identifier = "mass_action_create_shipments"
    callback = "massCreateShipments"

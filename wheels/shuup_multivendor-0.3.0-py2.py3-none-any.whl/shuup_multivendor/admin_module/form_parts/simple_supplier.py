# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import unicode_literals

from shuup.core.models import Supplier
from shuup.simple_supplier.admin_module.forms import \
    SimpleSupplierForm as BaseSimpleSupplierForm
from shuup.simple_supplier.admin_module.forms import \
    SimpleSupplierFormPart as BaseSimpleSupplierFormPart

from shuup_multivendor.supplier_provider import get_supplier


class SimpleSupplierForm(BaseSimpleSupplierForm):
    def get_suppliers(self, product):
        return Supplier.objects.filter(shop_products__product=product, pk=get_supplier(self.request).pk)

    def can_manage_stock(self):
        return get_supplier(self.request).stock_managed


class SimpleSupplierFormPart(BaseSimpleSupplierFormPart):
    form = SimpleSupplierForm

# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import unicode_literals

from django import forms
from django.conf import settings
from django.contrib.auth.models import Group
from django.utils.translation import ugettext_lazy as _
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.core.models import Label
from shuup.utils.importing import cached_load

from shuup_multivendor.admin_module.forms.vendor import (
    VendorForm, VendorOpeningPeriodsFormSet, VendorSettingsBaseForm
)
from shuup_multivendor.utils.configuration import (
    get_completed_status_label_for_shop, get_order_line_labels_for_shop,
    set_completed_status_label_for_shop, set_order_line_labels_for_shop
)
from shuup_multivendor.utils.permissions import (
    ensure_staff_permission_group_for_shop,
    ensure_staff_permission_group_permissions,
    ensure_vendor_permission_group_permissions,
    ensure_vendor_permissions_for_shop, get_staff_permission_group_for_shop,
    get_vendor_permission_group_for_shop, set_staff_permission_group_for_shop,
    set_vendor_permission_group_for_shop
)


class VendorConfigurationForm(forms.Form):
    staff_user_permission_group = forms.ModelChoiceField(
        label=_("Staff user permission group"),
        queryset=Group.objects.all(),
        help_text=_("Set the user group that should be used for staff users")
    )
    vendor_user_permission_group = forms.ModelChoiceField(
        label=_("Vendor user permission group"),
        queryset=Group.objects.all(),
        help_text=_("Set the user group that should be used for vendor users")
    )
    order_line_labels = forms.ModelMultipleChoiceField(
        label=_("Order line status available labels"),
        queryset=Label.objects.all(),
        help_text=_("Select all the label that can be used for order lines"),
        required=False
    )
    completed_status_label = forms.ModelChoiceField(
        label=_("Status that indicates completion"),
        queryset=Label.objects.all(),
        help_text=_(
            "Select the label that indicates the line is completed. "
            "When all lines have this status, the order will be "
            "changed to Complete."
        ),
        required=False
    )


class VendorConfigurationFormPart(FormPart):
    priority = 10
    name = "vendor_configuration"
    form = VendorConfigurationForm

    def get_form_defs(self):
        initial = {}
        if self.object.pk:
            initial = {
                "staff_user_permission_group": get_staff_permission_group_for_shop(self.object),
                "vendor_user_permission_group": get_vendor_permission_group_for_shop(self.object),
                "order_line_labels": [label.pk for label in get_order_line_labels_for_shop(self.object)],
                "completed_status_label": get_completed_status_label_for_shop(self.object)
            }

        yield TemplatedFormDef(
            name=self.name,
            form_class=self.form,
            template_name="shuup_multivendor/admin/form_parts/vendor.jinja",
            required=False,
            kwargs={"initial": initial}
        )

    def form_valid(self, form):
        vendor_form = form[self.name]

        if vendor_form.has_changed():
            staff_permission_group = vendor_form.cleaned_data["staff_user_permission_group"]
            vendor_permission_group = vendor_form.cleaned_data["vendor_user_permission_group"]
            order_line_labels = vendor_form.cleaned_data["order_line_labels"]
            completed_status_label = vendor_form.cleaned_data["completed_status_label"]
            set_staff_permission_group_for_shop(self.object, staff_permission_group)
            set_vendor_permission_group_for_shop(self.object, vendor_permission_group)
            set_order_line_labels_for_shop(self.object, order_line_labels)
            set_completed_status_label_for_shop(self.object, completed_status_label)

        current_staff_permission_group = get_staff_permission_group_for_shop(self.object)
        if current_staff_permission_group:
            # make sure staff permission group has all the required permissions
            ensure_staff_permission_group_permissions(current_staff_permission_group)
            # add all staff members to the staff permission group
            ensure_staff_permission_group_for_shop(self.object, current_staff_permission_group)

        current_vendor_permission_group = get_vendor_permission_group_for_shop(self.object)
        if current_vendor_permission_group:
            # make sure vendor permission group has all the required permissions
            ensure_vendor_permission_group_permissions(current_vendor_permission_group)
            # ensure all vendor users for this shop has correct permission group
            ensure_vendor_permissions_for_shop(self.object, current_vendor_permission_group)


class VendorBaseFormPart(FormPart):
    priority = 1

    def get_form_defs(self):
        yield TemplatedFormDef(
            "base",
            VendorForm,
            template_name="shuup_multivendor/admin/vendor/_edit_base_form.jinja",
            required=True,
            kwargs={
                "instance": self.object,
                "request": self.request,
                "languages": settings.LANGUAGES,
            }
        )

    def form_valid(self, form):
        self.object = form["base"].save()


class VendorSettingsBaseFormPart(VendorBaseFormPart):
    def get_form_defs(self):
        yield TemplatedFormDef(
            "base",
            VendorSettingsBaseForm,
            template_name="shuup_multivendor/admin/vendor/_edit_base_form.jinja",
            required=True,
            kwargs={
                "instance": self.object,
                "request": self.request,
                "languages": settings.LANGUAGES,
            }
        )


class VendorAddressFormPart(FormPart):
    priority = 2

    def get_form_defs(self):
        initial = {}
        yield TemplatedFormDef(
            "address",
            form_class=cached_load("SHUUP_MULTIVENDOR_ADDRESS_FORM"),
            template_name="shuup_multivendor/admin/vendor/_edit_contact_address_form.jinja",
            required=True,
            kwargs={
                "instance": self.object.contact_address,
                "initial": initial
            }
        )

    def form_valid(self, form):
        addr_form = form["address"]
        if addr_form.changed_data:
            addr = addr_form.save()
            setattr(self.object, "contact_address", addr)
            self.object.save()


class VendorOpeningPeriodsFormPart(FormPart):
    priority = 3

    def get_form_defs(self):
        if self.object.options:
            initial = [
                {
                    "day_of_week": period["day_of_week"],
                    "start": period["start"],
                    "end": period["end"]
                }
                for period in self.object.options.get("opening_periods", [])
            ]
        else:
            initial = []

        yield TemplatedFormDef(
            "opening_periods",
            VendorOpeningPeriodsFormSet,
            template_name="shuup_multivendor/admin/vendor/_edit_opening_periods_form.jinja",
            required=False,
            kwargs={
                "initial": initial
            }
        )

    def form_valid(self, form):
        opening_periods_form = form["opening_periods"]
        options = self.object.options or {}
        options["opening_periods"] = []

        for period in opening_periods_form.cleaned_data:
            options["opening_periods"].append({
                "day_of_week": period["day_of_week"],
                "start": period["start"].strftime("%H:%M"),
                "end": period["end"].strftime("%H:%M")
            })

        self.object.options = options
        self.object.save()

# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import unicode_literals

from django import forms
from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.lru_cache import lru_cache
from django.utils.translation import ugettext_lazy as _
from shuup.admin.forms.fields import (
    Select2ModelField, Select2ModelMultipleField
)
from shuup.admin.forms.widgets import TextEditorWidget
from shuup.admin.shop_provider import get_shop
from shuup.admin.signals import form_post_clean, form_pre_clean
from shuup.core.fields import (
    FORMATTED_DECIMAL_FIELD_DECIMAL_PLACES, FORMATTED_DECIMAL_FIELD_MAX_DIGITS,
    FormattedDecimalFormField
)
from shuup.core.models import (
    AnonymousContact, Category, CompanyContact, Manufacturer, PersonContact,
    Product, ProductType, ShopProduct
)
from shuup.customer_group_pricing.models import CgpDiscount
from shuup.utils.multilanguage_model_form import MultiLanguageModelForm

from shuup_multivendor.supplier_provider import get_supplier


@lru_cache()
def get_discount_contact_groups():
    return set([
        PersonContact.get_default_group(),
        AnonymousContact.get_default_group(),
        CompanyContact.get_default_group()
    ])


class VendorProductBaseForm(MultiLanguageModelForm):
    class Meta:
        model = Product
        fields = (
            "barcode",
            "depth",
            "gross_weight",
            "gtin",
            "height",
            "manufacturer",
            "net_weight",
            "sales_unit",
            "sku",
            "shipping_mode",
            "tax_class",
            "type",
            "width",
            "description",
            "short_description",
            "keywords",
            "name",
            "slug",
            "variation_name",
        )
        widgets = {
            "keywords": forms.TextInput(),
            "description": TextEditorWidget(),
            "short_description": forms.TextInput(),
        }

    def __init__(self, **kwargs):
        self.request = kwargs.pop('request', None)
        super(VendorProductBaseForm, self).__init__(**kwargs)

        self.fields["sales_unit"].required = True
        self.fields["shipping_mode"].required = False

        manufacturer = (self.instance.manufacturer if self.instance.pk else None)
        self.fields["manufacturer"] = Select2ModelField(required=False, initial=manufacturer, model=Manufacturer)
        if manufacturer:
            self.fields["manufacturer"].widget.choices = [(manufacturer.pk, manufacturer.name)]

        product_type = self.instance.type if self.instance.pk else kwargs.get("initial", {}).get("type")
        self.fields["type"] = Select2ModelField(label=_("Product type"), initial=product_type, model=ProductType)
        if product_type:
            self.fields["type"].widget.choices = [(product_type.pk, product_type.name)]

    def clean_sku(self):
        sku = self.cleaned_data["sku"]
        sku_unique_qs = Product.objects.filter(sku=sku)

        if self.instance:
            sku_unique_qs = sku_unique_qs.exclude(pk=self.instance.pk)

        # Make sure sku is unique and raise proper validation error if not
        if sku_unique_qs.exists():
            raise ValidationError(
                _("Given value is already in use, please use unique SKU and try again."), code="sku_not_unique")
        return sku

    def clean(self):
        form_pre_clean.send(Product, instance=self.instance, cleaned_data=self.cleaned_data)
        super(VendorProductBaseForm, self).clean()
        form_post_clean.send(Product, instance=self.instance, cleaned_data=self.cleaned_data)


class VendorShopProductForm(MultiLanguageModelForm):
    supplier_price = FormattedDecimalFormField(
        label=_("Price"),
        help_text=_(
            "This is the default individual base unit price of the product. "
            "All discounts or coupons will be based off of this price."
        ),
        decimal_places=FORMATTED_DECIMAL_FIELD_DECIMAL_PLACES,
        max_digits=FORMATTED_DECIMAL_FIELD_MAX_DIGITS,
        min_value=0
    )
    discount_amount = FormattedDecimalFormField(
        label=_("Discount amount"),
        help_text=_("Enter a discount amount for a special price."),
        required=False,
        decimal_places=FORMATTED_DECIMAL_FIELD_DECIMAL_PLACES,
        max_digits=FORMATTED_DECIMAL_FIELD_MAX_DIGITS,
        min_value=0
    )

    class Meta:
        model = ShopProduct
        fields = (
            "supplier_price",
            "discount_amount",
            "minimum_price_value",
            "visibility",
            "purchasable",
            "available_until",
            "purchase_multiple",
            "minimum_purchase_quantity",
            "backorder_maximum",
            "display_unit",
            "primary_category",
            "categories",
            "status_text",
        )
        help_texts = {
            "backorder_maximum": _("Number of units that can be purchased after the product is out of stock. "
                                   "Set to blank for product to be purchasable without limits")
        }

    def __init__(self, **kwargs):
        self.request = kwargs.pop("request", None)
        super(VendorShopProductForm, self).__init__(**kwargs)

        if self.instance.pk:
            from shuup_multivendor.models import SupplierPrice
            supplier_price = SupplierPrice.objects.filter(
                shop=get_shop(self.request),
                supplier=get_supplier(self.request),
                product=self.instance.product
            ).first()

            if supplier_price:
                self.fields["supplier_price"].initial = supplier_price.amount_value

        initial_categories = []

        if self.instance.pk:
            initial_categories = self.instance.categories.all()

            groups = get_discount_contact_groups()
            discount = CgpDiscount.objects.filter(
                product=self.instance.product,
                shop=get_shop(self.request),
                group__in=groups
            ).first()
            if discount:
                self.fields["discount_amount"].initial = discount.discount_amount.as_rounded().value

        self.fields["primary_category"] = Select2ModelField(
            initial=(self.instance.primary_category if self.instance.pk else None),
            model=Category,
            required=False
        )
        if self.instance.pk and self.instance.primary_category:
            self.fields["primary_category"].widget.choices = [
                (self.instance.primary_category.pk, self.instance.primary_category.name)
            ]

        self.fields["categories"] = Select2ModelMultipleField(
            initial=initial_categories,
            model=Category,
            required=False
        )
        if initial_categories:
            self.fields["categories"].widget.choices = [(cat.pk, cat.name) for cat in initial_categories]

    def clean_minimum_purchase_quantity(self):
        minimum_purchase_quantity = self.cleaned_data.get("minimum_purchase_quantity")
        if minimum_purchase_quantity <= 0:
            raise ValidationError(_("Minimum Purchase Quantity must be greater than 0."))
        return minimum_purchase_quantity

    def clean_backorder_maximum(self):
        backorder_maximum = self.cleaned_data.get("backorder_maximum")
        if backorder_maximum is not None and backorder_maximum < 0:
            raise ValidationError(_("Backorder maximum must be greater than or equal to 0."))
        return backorder_maximum

    def clean(self):
        form_pre_clean.send(ShopProduct, instance=self.instance, cleaned_data=self.cleaned_data)
        data = super(VendorShopProductForm, self).clean()

        if not getattr(settings, "SHUUP_AUTO_SHOP_PRODUCT_CATEGORIES", False):
            return data

        supplier_price = data.get("supplier_price")
        discount_amount = data.get("discount_amount")

        if discount_amount and discount_amount > supplier_price:
            self.add_error("discount_amount", _("Discount amount can't be greater than the product price."))

        # handle this here since form_part save causes problems with signals
        primary_category = data.get("primary_category")
        categories = data.get("categories", []) or []
        if categories:
            categories = list(categories)

        if not primary_category and categories:
            primary_category = categories[0]  # first is going to be primary

        if primary_category and primary_category not in categories:
            combined = [primary_category] + categories
            categories = combined

        data["primary_category"] = primary_category
        data["categories"] = categories

        form_post_clean.send(ShopProduct, instance=self.instance, cleaned_data=data)
        return data

    def save(self, commit=True):
        instance = super(VendorShopProductForm, self).save(commit)

        # TODO: Revise for option to share products while option to also create new ones.
        self.instance.suppliers = [get_supplier(self.request)]
        cleaned_data = self.cleaned_data
        groups = get_discount_contact_groups()

        from shuup_multivendor.models import SupplierPrice
        supplier_price_value = cleaned_data["supplier_price"]
        SupplierPrice.objects.update_or_create(
            shop=get_shop(self.request),
            supplier=get_supplier(self.request),
            product=self.instance.product,
            defaults=dict(amount_value=supplier_price_value)
        )

        if not instance.default_price_value:
            ShopProduct.objects.filter(pk=instance.pk).update(default_price_value=supplier_price_value)

        if cleaned_data.get("discount_amount"):
            for group in groups:
                CgpDiscount.objects.update_or_create(
                    product=instance.product,
                    shop=get_shop(self.request),
                    group=group,
                    defaults=dict(discount_amount_value=cleaned_data["discount_amount"])
                )
        else:
            CgpDiscount.objects.filter(
                product=instance.product,
                shop=get_shop(self.request),
                group__in=groups
            ).delete()

        return instance
